﻿/*
*/
var app = {
    cur: 0,//begin cursor
    size: 5,//retrieve size
    orderModel: {
        order: ko.observableArray([]),
        dealOrder: ko.observableArray([]),
    },
    order: ko.observableArray([]),
    dealOrder: ko.observableArray([]),
    dealList: [],
    bidList: [],//bid arr
    askList: [],//askArr

    fetchOrders: function (datas) {
        var self = this;
        var temp_orderArr = [];
        
        if (datas.length != 0) {
            datas.forEach(function (item) {
                if ("ask" == item.side) {
                    self.askList.push(item);
                }
                else if ("bid" == item.side) { self.bidList.push(item); }
            });
            if (self.askList.length > 20) {
                self.askList = self.askList.slice(0, 20);
            }
            if (self.bidList.length > 20) {
                self.bidList = self.bidList.slice(0, 20);
            }
            self.askList = self.sortArryAsc(self.askList);
            self.bidList = self.sortArryDesc(self.bidList);
            self.askList.forEach(function (item) { temp_orderArr.push(item); });
            self.bidList.forEach(function (item) { temp_orderArr.push(item); });
            temp_orderArr = self.sortArryDesc(temp_orderArr);
            self.orderModel.order(temp_orderArr);
            //self.orderModel.order = self.order;
            self.judingOrders(self.bidList, self.askList);
        }
        //setTimeout(fetchOrders, 2000);
    },

    Run: function () {
        //Retrieve orders
        var self = this;
        self.RetrieveOrders().then(function (ret) {
            self.fetchOrders(ret);
            self.cur += ret.length;
           

            setTimeout(self.Run(), 3000);

        }).fail(function (err) {
           
            setTimeout(self.Run(), 3000);

        });
    },

    RetrieveOrders: function () {
        var self = this;
        
        return $.Deferred(function (deferred) {
            $.ajax({
                type: "GET",
                url: "/listOrders",

                dataType: "json",
                data: {
                    "start": self.cur,
                    "size": self.size
                },
                success: function (resp) {
                    if (resp == null) {
                        deferred.reject({});
                    }
                    else {

                        deferred.resolve(resp);
                        //console.log("1:Ajax Retrieve datas Now");
                    }

                },
                error: function (jqXHR, exception) {
                    //console.log("Failed to get chain height!");
                    deferred.reject(jqXHR);
                }
            });
        }.bind(this)).promise();
    },

    initial: function () {
        var self = this;
        self.Run();
        ko.applyBindings(new this.PagedGridModel(self.orderModel));
        //ko.applyBindings(self.dealOrder());

    },

    sortArryAsc: function (arr) {
        arr = arr.sort(function (key1, key2) {
            if (key1.price > key2.price)
                return 1;
            else if (key1.price < key2.price)
                return -1;
            else if (key1.price == key2.price) {
                if (key1.number > key2.number) {
                    return 1;
                }
                else if (key1.number < key2.number) {
                    return -1;
                }
                else if (key1.number < key2.number) {
                    return 0;
                }
            }
        });
        return arr;
    },

    sortArryDesc: function (arr) {
        arr = arr.sort(function (key1, key2) {
            if (key1.price > key2.price)
                return -1;
            else if (key1.price < key2.price)
                return 1;
            else if (key1.price == key2.price) {
                if (key1.number > key2.number) {
                    return 1;
                }
                else if (key1.number < key2.number) {
                    return -1;
                }
                else if (key1.number < key2.number) {
                    return 0;
                }
            }
        });
        return arr;
    },

    sortArryDateDesc: function (arr) {
        arr = arr.sort(function (key1, key2) {
            if (new Date(key1.dealtime) > new Date(key2.dealtime))
                return -1;
            else if (new Date(key1.dealtime) < new Date(key2.dealtime))
                return 1;
            else if (new Date(key1.dealtime) > new Date(key2.dealtime)) {
                return 0;
            }
        });
        return arr;
    },

    judingOrders: function (bidList, askList) {
        var self = this;
        //console.log("4: juding orders Now");
        if (askList.length != 0 && bidList.length != 0) {
            var tempOrder = {};
            if (bidList[0].price > askList[0].price) {

                if (bidList[0].quantity > askList[0].quantity) {
                    //买家数量多于卖家 删除卖家 买家数量减去卖家数量

                    tempOrder.dealtime = new Date().format("yyyy-MM-dd hh:mm:ss");
                    tempOrder.quantity = askList[0].quantity;
                    tempOrder.price = Math.round((bidList[0].price + askList[0].price) / 2);
                    tempOrder.askModel = { "number": askList[0].number, "quantity": askList[0].quantity, "price": askList[0].price };
                    tempOrder.bidModel = { "number": bidList[0].number, "quantity": bidList[0].quantity, "price": bidList[0].price };
                    tempOrder.id = bidList[0].number + "_" + askList[0].number;
                    bidList[0].quantity -= askList[0].quantity;
                    askList.splice(0, 1);
                }
                else if (bidList[0].quantity < askList[0].quantity) {
                    //卖家数量多于买家 删除买家  买家数量减去买家数量

                    tempOrder.dealtime = new Date().format("yyyy-MM-dd hh:mm:ss");
                    tempOrder.quantity = bidList[0].quantity;
                    tempOrder.price = Math.round((bidList[0].price + askList[0].price) / 2);
                    tempOrder.askModel = { "number": askList[0].number, "quantity": askList[0].quantity, "price": askList[0].price };
                    tempOrder.bidModel = { "number": bidList[0].number, "quantity": bidList[0].quantity, "price": bidList[0].price };
                    tempOrder.id = bidList[0].number + "_" + askList[0].number;
                    askList[0].quantity -= bidList[0].quantity;
                    bidList.splice(0, 1);
                }
                else if (bidList[0].quantity == askList[0].quantity) {
                    //equals to each other
                    tempOrder.dealtime = new Date().format("yyyy-MM-dd hh:mm:ss");
                    tempOrder.quantity = bidList[0].quantity;
                    tempOrder.id = bidList[0].number + "_" + askList[0].number;
                    tempOrder.price = Math.round((bidList[0].price + askList[0].price) / 2);
                    tempOrder.askModel = { "number": askList[0].number, "quantity": askList[0].quantity, "price": askList[0].price };
                    tempOrder.bidModel = { "number": bidList[0].number, "quantity": bidList[0].quantity, "price": bidList[0].price };
                    askList.splice(0, 1);
                    bidList.splice(0, 1);
                }


                self.dealList.push(tempOrder);
                //show only 30 items
                if (self.dealList.length > 30) {
                    self.dealList = self.dealList.slice(0, 30);
                }
                self.dealList = self.sortArryDateDesc(self.dealList);
                //self.dealOrder(self.dealList);
                self.orderModel.dealOrder(self.dealList);
                self.judingOrders(bidList, askList);
            }
            else return false;
        }
        else return false;
    },
    PagedGridModel: function (items) {
        this.gridViewModel = new ko.simpleGrid.viewModel({
            data: items.order,
            columns: [
                { headerText: "交易单号", rowText: "number" },
                { headerText: "交易买卖", rowText: "side" },
                { headerText: "交易数量", rowText: "quantity" },
                { headerText: "交易价", rowText: function (item) { return "$" + item.price.toFixed(2) } }
            ],
            pageSize: 10
        });
    },

    doClick: function (item, index) {
        console.log("click to open ul");
        //$(".subContent").toggle();
        $("#" + item.id).toggle();
    },

};

app.initial();
Date.prototype.format = function (format) {
    var o = {
        "M+": this.getMonth() + 1, //month
        "d+": this.getDate(), //day
        "h+": this.getHours(), //hour
        "m+": this.getMinutes(), //minute
        "s+": this.getSeconds(), //second
        "q+": Math.floor((this.getMonth() + 3) / 3), //quarter
        "S": this.getMilliseconds() //millisecond
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
};

